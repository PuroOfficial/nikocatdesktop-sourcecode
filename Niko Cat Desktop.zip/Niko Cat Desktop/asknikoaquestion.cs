﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Niko_Cat_Desktop
{
    public partial class asknikoaquestion : Form
    {
        public asknikoaquestion()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Askbutton.Enabled = false;
            QuestionTextBox.Enabled = false;
            Console.WriteLine("niko is thinking...");
            Askbutton.Text = "Niko is thinking...";
            Random randomtick = new Random();
            int randomt = randomtick.Next(2000, 5000);
            nikothinkTimer.Interval = randomt;
            nikothinkTimer.Enabled = true;
        }

        private void nikothinkTimer_Tick(object sender, EventArgs e)
        {
            nikothinkTimer.Enabled = false;
            Random whatanswer = new Random();
            int randomanswer = whatanswer.Next(0, 10);
            if (randomanswer == 1)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_83c.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "I think yes!";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomanswer == 2)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "I think no...";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomanswer == 3)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_huh.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "I don't even know.";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomanswer == 4)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_83c.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "Probably?";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomanswer == 5)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_huh.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "Probably not...";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomanswer == 6)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_83c.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "Mhm!";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomanswer == 7)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_huh.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "I really understand this, But i don't want to answer.";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomanswer == 8)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_huh.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "Totally no!";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomanswer == 9)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko5.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "It depends.";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomanswer == 10)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_83c.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hmmmm....";
                notifyIcon1.BalloonTipText = "Totally yes!";
                notifyIcon1.ShowBalloonTip(10);
            }
            Askbutton.Text = "Ask";
            Askbutton.Enabled = true;
            QuestionTextBox.Enabled = true;
            Console.WriteLine("niko is done thining!");
        }

        private void asknikoaquestion_FormClosing(object sender, FormClosingEventArgs e)
        {
            notifyIcon1.Visible = false;
        }
    }
}
