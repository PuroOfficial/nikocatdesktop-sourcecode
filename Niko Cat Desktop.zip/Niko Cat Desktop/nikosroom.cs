﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Media;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Niko_Cat_Desktop
{
    public partial class nikosroom : Form
    {
        bool nikocursor = false;
        bool pccursor = false;
        bool gesturepressed = false;

        public nikosroom()
        {
            InitializeComponent();
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Make niko sleep in the bed? (Closes the application but don't worry, You can open this app anytime, Nothing will happen! :D)", "Niko Cat Desktop", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void interactcomputer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Message from the developer!", "Computer");
            if (MessageBox.Show("Do you wanna read it?", "Computer", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                SoundPlayer messagebox = new SoundPlayer(Properties.Resources.pc_messagebox);
                messagebox.Play();
                MessageBox.Show("Hello there, Player, I see you found this message in niko's computer.","Message from the developer!");
                messagebox.Play();
                MessageBox.Show("I am very suprised, I added it to v1.3...", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("Errrrrr.....", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("Do you understand niko is stuck in your desktop?", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("Wait....", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("I think you can still play oneshot while niko is in your desktop?", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("Hmmmmmmm......", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("Oh before you ask,", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("I am a developer I can't see if you played oneshot with niko cat desktop.", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("Do you understand?", "Message from the developer!", MessageBoxButtons.YesNo);
                messagebox.Play();
                MessageBox.Show("Very well.", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("I am not a computer, I put this message on niko's computer.", "Message from the developer!");
                MessageBox.Show("Who am i, Crazy?", "Message from the developer!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                messagebox.Play();
                MessageBox.Show("Well anyway, I hope you found this message and will take care niko very great, Even tho niko could die if you do not feed her pancakes, I hope you make progress.", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("Do you understand?", "Message from the developer!", MessageBoxButtons.YesNo);
                messagebox.Play();
                MessageBox.Show("Well I need to stop talking so you can play the game normally.", "Message from the developer!");
                messagebox.Play();
                MessageBox.Show("Anyways, Goodbye! -Puro", "Message from the developer!");
                MessageBox.Show("End of line.", "Computer", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            nikocursor = true;
            hoverTimer.Enabled = true;
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            nikocursor = false;
            hoverTimer.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (nikocursor == true)
            {
                if (gesturepressed == false)
                {
                    notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_huh.ico"));
                    notifyIcon1.Text = "Niko";
                    notifyIcon1.Visible = true;
                    notifyIcon1.BalloonTipTitle = "Don't stare please!~";
                    notifyIcon1.BalloonTipText = "It makes me nervous.";
                    notifyIcon1.ShowBalloonTip(10);
                    hoverTimer.Enabled = false;
                }
                else
                {
                    if (pictureBox1.Enabled == true)
                    {
                        notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_pancakes.ico"));
                        notifyIcon1.Text = "Niko";
                        notifyIcon1.Visible = true;
                        notifyIcon1.BalloonTipTitle = "Thank you!~";
                        notifyIcon1.BalloonTipText = "-w-";
                        notifyIcon1.ShowBalloonTip(10);
                    }
                    hoverTimer.Enabled = false;
                }
            }
            if (pccursor == true)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_speak.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Oh you're wondering what this is?";
                notifyIcon1.BalloonTipText = "This is a computer!";
                notifyIcon1.ShowBalloonTip(10);
                hoverTimer.Enabled = false;
            }
        }

        private void interactcomputer_MouseEnter(object sender, EventArgs e)
        {
            pccursor = true;
            hoverTimer.Enabled = true;
        }

        private void interactcomputer_MouseLeave(object sender, EventArgs e)
        {
            pccursor = false;
            hoverTimer.Enabled = false;
        }

        private void nikosroom_KeyDown(object sender, KeyEventArgs e)
        {
            Console.WriteLine("key press");
            if (e.KeyCode == Keys.E)
            {
                Console.WriteLine("e pressed");
                if (gesturepressed == false)
                {
                    gesturepressed = true;
                    label1.Text = "Press [E] to change gesture. | Hand";
                    this.Cursor = Cursors.Hand;
                }
                else
                {
                    gesturepressed = false;
                    label1.Text = "Press [E] to change gesture. | Cursor";
                    this.Cursor = Cursors.Default;
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (textBox1.Enabled == false)
            {
                textBox1.Enabled = true;
            }
            else
            {
                textBox1.Enabled = false;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (gesturepressed == true)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_huh.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Hey!";
                notifyIcon1.BalloonTipText = "Don't poke me!";
                notifyIcon1.ShowBalloonTip(10);
                pictureBox1.Enabled = false;
                cooldownTimer.Enabled = true;
            }
        }

        private void cooldownTimer_Tick(object sender, EventArgs e)
        {
            pictureBox1.Enabled = true;
            cooldownTimer.Enabled = false;
        }
    }
}
