﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Niko_Cat_Desktop
{
    public partial class nikosroom : Form
    {
        public nikosroom()
        {
            InitializeComponent();
        }
    }
}
