﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Niko_Cat_Desktop
{
    public partial class nikosroom : Form
    {
        public nikosroom()
        {
            InitializeComponent();
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Make niko sleep in the bed? (Closes the application but don't worry, You can open this app anytime, Nothing will happen! :D)", "Niko Cat Desktop", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void interactcomputer_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Message from the developer!", "Computer");
            if (MessageBox.Show("Do you wanna read it?", "Computer", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                MessageBox.Show("Hello there, Player, I see you found this message in niko's computer.","Message from the developer!");
                MessageBox.Show("I am very suprised, I added it to v1.3...", "Message from the developer!");
                MessageBox.Show("Errrrrr.....", "Message from the developer!");
                MessageBox.Show("Do you understand niko is stuck in your desktop?", "Message from the developer!");
                MessageBox.Show("Wait....", "Message from the developer!");
                MessageBox.Show("I think you can still play oneshot while niko is in your desktop?", "Message from the developer!");
                MessageBox.Show("Hmmmmmmm......", "Message from the developer!");
                MessageBox.Show("Oh before you ask,", "Message from the developer!");
                MessageBox.Show("I am a developer I can't see if you played oneshot with niko cat desktop.", "Message from the developer!");
                MessageBox.Show("Do you understand?", "Message from the developer!", MessageBoxButtons.YesNo);
                MessageBox.Show("Very well.", "Message from the developer!");
                MessageBox.Show("I am not a computer, I put this message on niko's computer.", "Message from the developer!");
                MessageBox.Show("Who am i, Crazy?", "Message from the developer!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                MessageBox.Show("Well anyway, I hope you found this message and will take care niko very great, Even tho niko could die if you do not feed her pancakes, I hope you make progress.", "Message from the developer!");
                MessageBox.Show("Do you understand?", "Message from the developer!", MessageBoxButtons.YesNo);
                MessageBox.Show("Well I need to stop talking so you can play the game normally.", "Message from the developer!");
                MessageBox.Show("Anyways, Goodbye! -Puro", "Message from the developer!");
                MessageBox.Show("End of line.", "Computer", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
