﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Media;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Niko_Cat_Desktop
{
    public partial class Form1 : Form
    {
        int nikox;
        int nikoy;
        int nikooffset;
        bool nikodead;
        bool turbo;
        public Form1()
        {
            InitializeComponent();
            nikox = 380;
            nikooffset = 740;
            nikodead = false;
            nikooffsetpanel.Visible = false;
            pancakes.Visible = false;
            notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_smile.ico"));
            notifyIcon1.Text = "Niko";
            notifyIcon1.Visible = true;
            notifyIcon1.BalloonTipTitle = "hiiii";
            notifyIcon1.BalloonTipText = "i am cat from that one game";
            notifyIcon1.ShowBalloonTip(10);
            MessageBox.Show("Welcome to Niko Cat Desktop, Where you play around with niko, also feed niko her pancakes, she may die, But if you want to exit out right click on niko (bet you can if niko moves so fast) and click exit, Also if your wandering why niko is not talking unmute your notifications, But if your lazy catching niko and right clicking her i also added a niko icon located in your icons right side in your taskbar! Made in Visual Studio 2019 as always.", "Hello!");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (standStillToolStripMenuItem.Checked == false)
            {
                Random randomwhereto = new Random();
                int random = randomwhereto.Next(0, 4);
                if (random > 2)
                {
                    if (turbo == false)
                    {
                        niko.Image = Niko_Cat_Desktop.Properties.Resources.nikoleft;
                    }
                    if (turbo == true)
                    {
                        niko.Image = Niko_Cat_Desktop.Properties.Resources.niko_roomba_left;
                    }
                    nikox = nikox - 25;
                    nikoy = niko.Location.Y;
                    niko.Left = nikox;
                }
                else
                {
                    if (niko.Left < nikooffset)
                    {
                        if (turbo == false)
                        {
                            niko.Image = Niko_Cat_Desktop.Properties.Resources.nikoright;
                        }
                        if (turbo == true)
                        {
                            niko.Image = Niko_Cat_Desktop.Properties.Resources.niko_roomba_right;
                        }
                        nikox = nikox + 25;
                        nikoy = niko.Location.Y;
                        niko.Left = nikox;
                    }
                    else
                    {
                        if (turbo == false)
                        {
                            niko.Image = Niko_Cat_Desktop.Properties.Resources.nikoright;
                        }
                        if (turbo == true)
                        {
                            niko.Image = Niko_Cat_Desktop.Properties.Resources.niko_roomba_right;
                        }
                        nikox = nikox - 25;
                        nikoy = niko.Location.Y;
                        niko.Left = nikox;
                    }
                }
            }
        }

        private void messageTimer_Tick(object sender, EventArgs e)
        {
            if(nikodead == false)
            {
            Random randomwhatmessage = new Random();
            int randomwm = randomwhatmessage.Next(0, 15);
            if (randomwm == 1)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_pancakes.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "you got any pancakes on your phone?";
                notifyIcon1.BalloonTipText = "i love pancakes :3";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomwm == 2)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_smile.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "fact";
                notifyIcon1.BalloonTipText = "i am a cat";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomwm == 3)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_pancakes.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "play oneshot";
                notifyIcon1.BalloonTipText = "Pleaseeeeeeeeeeee";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomwm == 4)
            {
                pancakes.Visible = true;
                CheckNikowasFed.Enabled = true;
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_smile.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "feed me";
                notifyIcon1.BalloonTipText = "feed me pancakes.";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomwm == 5)
            {
                if (googleStuffToolStripMenuItem.Checked == true)
                {
                    notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_smile.ico"));
                    notifyIcon1.Text = "Niko";
                    notifyIcon1.Visible = true;
                    notifyIcon1.BalloonTipTitle = "watch me go";
                    notifyIcon1.BalloonTipText = "i am gonna google something :3";
                    notifyIcon1.ShowBalloonTip(10);
                    System.Diagnostics.Process.Start("https://www.google.com/search?q=how+to+beat+oneshot");
                }
            }
            if (randomwm == 6)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "meow";
                notifyIcon1.BalloonTipText = "meow meow meow meow meow.";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomwm == 7)
            {
                if (googleStuffToolStripMenuItem.Checked == true)
                {
                    notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_smile.ico"));
                    notifyIcon1.Text = "Niko";
                    notifyIcon1.Visible = true;
                    notifyIcon1.BalloonTipTitle = "Hey!";
                    notifyIcon1.BalloonTipText = "Can you please let me out outside, Is so boring here.";
                    notifyIcon1.ShowBalloonTip(10);
                    System.Diagnostics.Process.Start("https://youtu.be/OeUaRJKO7BI?t=22");
                }
            }
            if (randomwm == 8)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_distressed.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "I'm not sure what to do here?";
                notifyIcon1.BalloonTipText = "Do you player?";
                notifyIcon1.ShowBalloonTip(10);
                SoundPlayer idk = new SoundPlayer(Properties.Resources.idk);
                idk.Play();
            }
            if (randomwm == 9)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_smile.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Are you not even paying attetion to me?";
                notifyIcon1.BalloonTipText = "I am cat, You most take care of me!";
                notifyIcon1.ShowBalloonTip(10);
            }
            if (randomwm == 10)
            {
                if (googleStuffToolStripMenuItem.Checked == true)
                {
                    notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_pancakes.ico"));
                    notifyIcon1.Text = "Niko";
                    notifyIcon1.Visible = true;
                    notifyIcon1.BalloonTipTitle = "Swag like niko!";
                    notifyIcon1.BalloonTipText = "hell yeah niko plushie goes hard 🔥🔥🔥";
                    notifyIcon1.ShowBalloonTip(10);
                    System.Diagnostics.Process.Start("https://www.youtube.com/watch?v=BvZfEaqLUUY");
                }
            }
            if (randomwm == 11)
            {
                if (googleStuffToolStripMenuItem.Checked == true)
                {
                    notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_smile.ico"));
                    notifyIcon1.Text = "Niko";
                    notifyIcon1.Visible = true;
                    notifyIcon1.BalloonTipTitle = "huh?";
                    notifyIcon1.BalloonTipText = "huh?";
                    notifyIcon1.ShowBalloonTip(10);
                    System.Diagnostics.Process.Start("https://www.youtube.com/watch?v=-wrmxQdTs6c");
                }
            }
            if (randomwm == 12)
            {
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_speak.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Gotcha!";
                notifyIcon1.BalloonTipText = ">:3";
                notifyIcon1.ShowBalloonTip(10);
                Console.WriteLine("attempting to use win32");
                Win32.ClientToScreen(this.Handle);
                Win32.SetCursorPos(nikox, -900);
                Console.WriteLine("now cursor");
                Cursor = new Cursor(Cursor.Current.Handle);
                Cursor.Position = new Point(nikox, nikoy);
                Console.WriteLine(Cursor.Position.X.ToString(), Cursor.Position.Y.ToString());
            }
            }
        }

        private Point _mouseLoc;
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            _mouseLoc = e.Location;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                int dx = e.Location.X - _mouseLoc.X;
                int dy = e.Location.Y - _mouseLoc.Y;
                int pancakex;
                this.pancakes.Location = new Point(this.pancakes.Location.X + dx, this.pancakes.Location.Y + dy);
                pancakex = this.pancakes.Location.X;
                if (pancakex == nikox)
                {
                    if (this.pancakes.Visible == false)
                    {
                        Console.WriteLine("this is hidden so it can't be active and this.");
                        return;
                    }
                    else
                    {
                        this.pancakes.Visible = false;
                        this.pancakes.Location = new Point(0,0);
                        Console.WriteLine("niko was fed, good job.");
                        notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_pancakes.ico"));
                        notifyIcon1.Text = "Niko";
                        notifyIcon1.Visible = true;
                        notifyIcon1.BalloonTipTitle = "thanks";
                        notifyIcon1.BalloonTipText = "thank you for feeding me pancakes";
                        notifyIcon1.ShowBalloonTip(10);
                    }
                }
            }
        }

        private void CheckNikowasFed_Tick(object sender, EventArgs e)
        {
            if (pancakes.Visible == true)
            {
                Console.WriteLine("you killed niko.");
                niko.Visible = false;
                nikodead = true;
                Console.WriteLine("niko is died.");
                MessageBox.Show("You forgot to feed niko!","you forgor", MessageBoxButtons.OK, MessageBoxIcon.Error);
                CheckNikowasFed.Enabled = false;
                Application.Exit();
            }
            else
            {
                CheckNikowasFed.Enabled = false;
            }
        }

        private void nikosStatusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (pancakes.Visible == false)
            {
                MessageBox.Show("Niko is ok and not hungry.","Niko's Status");
            }
            else
            {
                MessageBox.Show("Niko needs to be fed.", "Niko's Status");
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Exiting...");
            Application.Exit();
        }

        private void googleStuffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (googleStuffToolStripMenuItem.Checked == true)
            {
                Console.WriteLine("google stuff disabled.");
                googleStuffToolStripMenuItem.Checked = false;
            }
            else
            {
                Console.WriteLine("google stuff enabled.");
                googleStuffToolStripMenuItem.Checked = true;
            }
        }

        private void standStillToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (standStillToolStripMenuItem.Checked == true)
            {
                Console.WriteLine("stand still disabled.");
                standStillToolStripMenuItem.Checked = false;
            }
            else
            {
                Console.WriteLine("stand still enabled.");
                standStillToolStripMenuItem.Checked = true;
            }
        }

        private void AppDetectTimer_Tick(object sender, EventArgs e)
        {
            Random randomwhatmessagegame = new Random();
            int randomwmg = randomwhatmessagegame.Next(0, 5);
            Process[] pname = Process.GetProcessesByName("RobloxPlayerLauncher.exe");
            if (pname.Length > 0)
            {
                Console.WriteLine("running process found.");
                if (randomwmg == 1)
                {
                    notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_huh.ico"));
                    notifyIcon1.Text = "Niko";
                    notifyIcon1.Visible = true;
                    notifyIcon1.BalloonTipTitle = "...";
                    notifyIcon1.BalloonTipText = "really?, playing a game?";
                    notifyIcon1.ShowBalloonTip(10);
                }
                if (randomwmg == 2)
                {
                    notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_less_sad.ico"));
                    notifyIcon1.Text = "Niko";
                    notifyIcon1.Visible = true;
                    notifyIcon1.BalloonTipTitle = "That is not funny!";
                    notifyIcon1.BalloonTipText = "What if i need pancakes? HUH?!";
                    notifyIcon1.ShowBalloonTip(10);
                }
                if (randomwmg == 3)
                {
                    notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_huh.ico"));
                    notifyIcon1.Text = "Niko";
                    notifyIcon1.Visible = true;
                    notifyIcon1.BalloonTipTitle = "Do you care about entertainment?";
                    notifyIcon1.BalloonTipText = "if so stop.";
                    notifyIcon1.ShowBalloonTip(10);
                }
                if (randomwmg == 4)
                {
                    notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_cry.ico"));
                    notifyIcon1.Text = "Niko";
                    notifyIcon1.Visible = true;
                    notifyIcon1.BalloonTipTitle = "Your cruel player.";
                    notifyIcon1.BalloonTipText = "Stop.";
                    notifyIcon1.ShowBalloonTip(10);
                }
            }
        }

        private void nikosroom_door_Click(object sender, EventArgs e)
        {
            if (niko.Visible == false)
            {
                Console.WriteLine("opened");
                messageTimer.Enabled = false;
                SoundPlayer dooropen = new SoundPlayer(Properties.Resources.door_open);
                dooropen.Play();
                niko.Visible = false;
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_pancakes.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "Welcome to my room, Player!";
                notifyIcon1.BalloonTipText = "Take a look around!";
                notifyIcon1.ShowBalloonTip(10);
                using (var nikosroom = new nikosroom())
                {
                    nikosroom.ShowDialog();
                    Console.WriteLine("closed");
                    niko.Visible = true;
                    messageTimer.Enabled = true;
                }
            }
            else
            {
                Console.WriteLine("niko went to her room");
                messageTimer.Enabled = false;
                SoundPlayer dooropen = new SoundPlayer(Properties.Resources.door_open);
                dooropen.Play();
                niko.Visible = false;
                notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_speak.ico"));
                notifyIcon1.Text = "Niko";
                notifyIcon1.Visible = true;
                notifyIcon1.BalloonTipTitle = "I gonna go to my room, Player!";
                notifyIcon1.BalloonTipText = "Cya, If you need anything go to my room!";
                notifyIcon1.ShowBalloonTip(10);
            }
        }

        private void askNikoAQuestionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Console.WriteLine("opened");
            messageTimer.Enabled = false;
            notifyIcon1.Visible = false;
            using (var askniko = new asknikoaquestion())
            {
                askniko.ShowDialog();
                Console.WriteLine("closed");
                messageTimer.Enabled = true;
                notifyIcon1.Visible = true;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            notifyIcon1.Visible = false;
        }

        private void hideNikosRoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (hideNikosRoomToolStripMenuItem.Checked == true)
            {
                Console.WriteLine("hide niko's room disabled.");
                hideNikosRoomToolStripMenuItem.Checked = false;
                nikosroom_door.Visible = true;
            }
            else
            {
                Console.WriteLine("hide niko's room enabled.");
                hideNikosRoomToolStripMenuItem.Checked = true;
                nikosroom_door.Visible = false;
            }
        }

        private void niko_MouseDown(object sender, MouseEventArgs e)
        {
            notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_shock.ico"));
            notifyIcon1.Text = "Niko";
            notifyIcon1.Visible = true;
            notifyIcon1.BalloonTipTitle = "Ahhhh!";
            notifyIcon1.BalloonTipText = "Put me down, Player!";
            notifyIcon1.ShowBalloonTip(10);
            standStillToolStripMenuItem.Checked = true;
            _mouseLoc = e.Location;
        }

        private void niko_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                int dx = e.Location.X - _mouseLoc.X;
                int dy = e.Location.Y - _mouseLoc.Y;
                this.niko.Location = new Point(this.niko.Location.X + dx, this.niko.Location.Y + dy);
                nikox = this.niko.Location.X;
            }
        }

        private void niko_MouseUp(object sender, MouseEventArgs e)
        {
            standStillToolStripMenuItem.Checked = false;
        }

        private void nikosroom_door_MouseHover(object sender, EventArgs e)
        {
            this.nikosroom_door.Image = (Properties.Resources.door2);
        }

        private void nikosroom_door_MouseLeave(object sender, EventArgs e)
        {
            this.nikosroom_door.Image = (Properties.Resources.door);
        }

        private void turbooooooooooooToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (turbooooooooooooToolStripMenuItem.Checked == true)
            {
                Console.WriteLine("turbo disabled.");
                turbooooooooooooToolStripMenuItem.Checked = false;
                turbo = false;
                moveTimer.Interval = 500;
            }
            else
            {
                Console.WriteLine("turbo enabled.");
                turbooooooooooooToolStripMenuItem.Checked = true;
                turbo = true;
                moveTimer.Interval = 50;
            }
        }

        private void nikosOffsetPanelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (nikosOffsetPanelToolStripMenuItem.Checked == true)
            {
                Console.WriteLine("nikos offset panel disabled.");
                nikosOffsetPanelToolStripMenuItem.Checked = false;
                nikooffsetpanel.Visible = false;
            }
            else
            {
                Console.WriteLine("nikos offset panel enabled.");
                nikosOffsetPanelToolStripMenuItem.Checked = true;
                nikooffsetpanel.Visible = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            nikooffset = ((int)OffsetnumericUpDown.Value);
        }

        private void fixoffsettimer_Tick(object sender, EventArgs e)
        {
            nikoy = niko.Location.Y;
        }

        private void nikoSaysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Console.WriteLine("playing");
            messageTimer.Enabled = false;
            niko.Visible = false;
            nikosroom_door.Visible = false;
            notifyIcon1.Icon = new System.Drawing.Icon(Path.GetFullPath("niko_pancakes.ico"));
            notifyIcon1.Text = "Niko";
            notifyIcon1.Visible = true;
            notifyIcon1.BalloonTipTitle = "Let's play!";
            notifyIcon1.BalloonTipText = "It will be fun!";
            notifyIcon1.ShowBalloonTip(10);
            using (var nikosays = new nikosays())
            {
                nikosays.ShowDialog();
                Console.WriteLine("closed");
                niko.Visible = true;
                nikosroom_door.Visible = true;
                messageTimer.Enabled = true;
            }
        }
    }
}

public class Win32
{
    [DllImport("User32.Dll")]
    public static extern long SetCursorPos(int x, int y);

    [DllImport("User32.Dll")]
    public static extern bool ClientToScreen(IntPtr hWndenin);

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT
    {
        public int x;
        public int y;

        public POINT(int X, int Y)
        {
            x = X;
            y = Y;
        }
    }
}