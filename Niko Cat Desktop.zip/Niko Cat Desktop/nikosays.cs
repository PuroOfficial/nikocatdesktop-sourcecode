﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Niko_Cat_Desktop
{
    public partial class nikosays : Form
    {
        bool redentered = false;
        bool yellowentered = false;
        bool greenentered = false;
        bool blueentered = false;
        int whatcolorstand = 0;
        Random randomwhatstandon = new Random();
        int randomwso;
        // 0, null | 1, Red | 2, Yellow | 3, Green | 4, Blue
        public nikosays()
        {
            InitializeComponent();
        }

        private void redpanel_MouseEnter(object sender, EventArgs e)
        {
            redentered = true;
        }

        private void redpanel_MouseLeave(object sender, EventArgs e)
        {
            redentered = false;
        }

        private void yellowpanel_MouseEnter(object sender, EventArgs e)
        {
            yellowentered = true;
        }

        private void yellowpanel_MouseLeave(object sender, EventArgs e)
        {
            yellowentered = false;
        }

        private void greenpanel_MouseEnter(object sender, EventArgs e)
        {
            greenentered = true;
        }

        private void greenpanel_MouseLeave(object sender, EventArgs e)
        {
            greenentered = false;
        }

        private void bluepanel_MouseEnter(object sender, EventArgs e)
        {
            blueentered = true;
        }

        private void bluepanel_MouseLeave(object sender, EventArgs e)
        {
            blueentered = false;
        }

        private void thinkTimer_Tick(object sender, EventArgs e)
        {
            thinkTimer.Enabled = false;
            randomwso = randomwhatstandon.Next(1, 4);
            if (randomwso == 1)
            {
                nikosaid.Text = "Niko says go to red!";
            }
            if (randomwso == 2)
            {
                nikosaid.Text = "Niko says go to yellow!";
            }
            if (randomwso == 3)
            {
                nikosaid.Text = "Niko says go to green!";
            }
            if (randomwso == 4)
            {
                nikosaid.Text = "Niko says go to blue!";
            }
            checkTimer.Enabled = true;
        }

        private void checkTimer_Tick(object sender, EventArgs e)
        {
            checkTimer.Enabled = false;
            nikosaid.Text = "Niko is thinking what do you need to stand on...";
            if (randomwso == 1)
            {
                if(redentered == true)
                {

                }
                else
                {
                    MessageBox.Show("You didn't place on red! :O","Niko wins!");
                    this.Close();
                }
            }
            if (randomwso == 2)
            {
                if (yellowentered == true)
                {

                }
                else
                {
                    MessageBox.Show("You didn't place on yellow! :O", "Niko wins!");
                    this.Close();
                }
            }
            if (randomwso == 3)
            {
                if (greenentered == true)
                {

                }
                else
                {
                    MessageBox.Show("You didn't place on green! :O", "Niko wins!");
                    this.Close();
                }
            }
            if (randomwso == 4)
            {
                if (blueentered == true)
                {

                }
                else
                {
                    MessageBox.Show("You didn't place on blue! :O", "Niko wins!");
                    this.Close();
                }
            }
            thinkTimer.Enabled = true;
        }
    }
}
