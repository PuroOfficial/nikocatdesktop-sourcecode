﻿
namespace Niko_Cat_Desktop
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.nikosStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.askNikoAQuestionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.playAGameWithNikoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nikoSaysToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.standStillToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hideNikosRoomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.googleStuffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.turbooooooooooooToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nikosOffsetPanelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moveTimer = new System.Windows.Forms.Timer(this.components);
            this.messageTimer = new System.Windows.Forms.Timer(this.components);
            this.CheckNikowasFed = new System.Windows.Forms.Timer(this.components);
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.AppDetectTimer = new System.Windows.Forms.Timer(this.components);
            this.nikooffsetpanel = new System.Windows.Forms.Panel();
            this.OffsetnumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.settoffsetbutton = new System.Windows.Forms.Button();
            this.offsetlabel = new System.Windows.Forms.Label();
            this.fixoffsettimer = new System.Windows.Forms.Timer(this.components);
            this.nikosroom_door = new System.Windows.Forms.PictureBox();
            this.pancakes = new System.Windows.Forms.PictureBox();
            this.niko = new System.Windows.Forms.PictureBox();
            this.randomstoppingTimer = new System.Windows.Forms.Timer(this.components);
            this.muteFootstepsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.nikooffsetpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OffsetnumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nikosroom_door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pancakes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.niko)).BeginInit();
            this.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nikosStatusToolStripMenuItem,
            this.askNikoAQuestionToolStripMenuItem,
            this.playAGameWithNikoToolStripMenuItem,
            this.standStillToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(196, 158);
            // 
            // nikosStatusToolStripMenuItem
            // 
            this.nikosStatusToolStripMenuItem.Name = "nikosStatusToolStripMenuItem";
            this.nikosStatusToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.nikosStatusToolStripMenuItem.Text = "Niko\'s Status";
            this.nikosStatusToolStripMenuItem.Click += new System.EventHandler(this.nikosStatusToolStripMenuItem_Click);
            // 
            // askNikoAQuestionToolStripMenuItem
            // 
            this.askNikoAQuestionToolStripMenuItem.Name = "askNikoAQuestionToolStripMenuItem";
            this.askNikoAQuestionToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.askNikoAQuestionToolStripMenuItem.Text = "Ask Niko a Question!";
            this.askNikoAQuestionToolStripMenuItem.Click += new System.EventHandler(this.askNikoAQuestionToolStripMenuItem_Click);
            // 
            // playAGameWithNikoToolStripMenuItem
            // 
            this.playAGameWithNikoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nikoSaysToolStripMenuItem});
            this.playAGameWithNikoToolStripMenuItem.Name = "playAGameWithNikoToolStripMenuItem";
            this.playAGameWithNikoToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.playAGameWithNikoToolStripMenuItem.Text = "Play a game with Niko!";
            // 
            // nikoSaysToolStripMenuItem
            // 
            this.nikoSaysToolStripMenuItem.Name = "nikoSaysToolStripMenuItem";
            this.nikoSaysToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.nikoSaysToolStripMenuItem.Text = "Niko Says";
            this.nikoSaysToolStripMenuItem.Click += new System.EventHandler(this.nikoSaysToolStripMenuItem_Click);
            // 
            // standStillToolStripMenuItem
            // 
            this.standStillToolStripMenuItem.Name = "standStillToolStripMenuItem";
            this.standStillToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.standStillToolStripMenuItem.Text = "Stand Still";
            this.standStillToolStripMenuItem.Click += new System.EventHandler(this.standStillToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hideNikosRoomToolStripMenuItem,
            this.muteFootstepsToolStripMenuItem,
            this.googleStuffToolStripMenuItem,
            this.turbooooooooooooToolStripMenuItem,
            this.nikosOffsetPanelToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // hideNikosRoomToolStripMenuItem
            // 
            this.hideNikosRoomToolStripMenuItem.Name = "hideNikosRoomToolStripMenuItem";
            this.hideNikosRoomToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.hideNikosRoomToolStripMenuItem.Text = "Hide Niko\'s Room";
            this.hideNikosRoomToolStripMenuItem.Click += new System.EventHandler(this.hideNikosRoomToolStripMenuItem_Click);
            // 
            // googleStuffToolStripMenuItem
            // 
            this.googleStuffToolStripMenuItem.Checked = true;
            this.googleStuffToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.googleStuffToolStripMenuItem.Name = "googleStuffToolStripMenuItem";
            this.googleStuffToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.googleStuffToolStripMenuItem.Text = "Google Stuff?";
            this.googleStuffToolStripMenuItem.Click += new System.EventHandler(this.googleStuffToolStripMenuItem_Click);
            // 
            // turbooooooooooooToolStripMenuItem
            // 
            this.turbooooooooooooToolStripMenuItem.Name = "turbooooooooooooToolStripMenuItem";
            this.turbooooooooooooToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.turbooooooooooooToolStripMenuItem.Text = "Turboooooooooooo";
            this.turbooooooooooooToolStripMenuItem.Click += new System.EventHandler(this.turbooooooooooooToolStripMenuItem_Click);
            // 
            // nikosOffsetPanelToolStripMenuItem
            // 
            this.nikosOffsetPanelToolStripMenuItem.Name = "nikosOffsetPanelToolStripMenuItem";
            this.nikosOffsetPanelToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.nikosOffsetPanelToolStripMenuItem.Text = "Niko\'s Offset Panel";
            this.nikosOffsetPanelToolStripMenuItem.Click += new System.EventHandler(this.nikosOffsetPanelToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // moveTimer
            // 
            this.moveTimer.Enabled = true;
            this.moveTimer.Interval = 500;
            this.moveTimer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // messageTimer
            // 
            this.messageTimer.Enabled = true;
            this.messageTimer.Interval = 20000;
            this.messageTimer.Tick += new System.EventHandler(this.messageTimer_Tick);
            // 
            // CheckNikowasFed
            // 
            this.CheckNikowasFed.Interval = 10000;
            this.CheckNikowasFed.Tick += new System.EventHandler(this.CheckNikowasFed_Tick);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // AppDetectTimer
            // 
            this.AppDetectTimer.Enabled = true;
            this.AppDetectTimer.Interval = 25000;
            this.AppDetectTimer.Tick += new System.EventHandler(this.AppDetectTimer_Tick);
            // 
            // nikooffsetpanel
            // 
            this.nikooffsetpanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.nikooffsetpanel.BackColor = System.Drawing.Color.White;
            this.nikooffsetpanel.Controls.Add(this.OffsetnumericUpDown);
            this.nikooffsetpanel.Controls.Add(this.settoffsetbutton);
            this.nikooffsetpanel.Controls.Add(this.offsetlabel);
            this.nikooffsetpanel.Location = new System.Drawing.Point(711, 526);
            this.nikooffsetpanel.Name = "nikooffsetpanel";
            this.nikooffsetpanel.Size = new System.Drawing.Size(77, 68);
            this.nikooffsetpanel.TabIndex = 3;
            // 
            // OffsetnumericUpDown
            // 
            this.OffsetnumericUpDown.Increment = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.OffsetnumericUpDown.Location = new System.Drawing.Point(0, 16);
            this.OffsetnumericUpDown.Maximum = new decimal(new int[] {
            70020,
            0,
            0,
            0});
            this.OffsetnumericUpDown.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.OffsetnumericUpDown.Name = "OffsetnumericUpDown";
            this.OffsetnumericUpDown.Size = new System.Drawing.Size(77, 20);
            this.OffsetnumericUpDown.TabIndex = 3;
            this.OffsetnumericUpDown.Value = new decimal(new int[] {
            740,
            0,
            0,
            0});
            // 
            // settoffsetbutton
            // 
            this.settoffsetbutton.Location = new System.Drawing.Point(2, 42);
            this.settoffsetbutton.Name = "settoffsetbutton";
            this.settoffsetbutton.Size = new System.Drawing.Size(75, 23);
            this.settoffsetbutton.TabIndex = 2;
            this.settoffsetbutton.Text = "Set";
            this.settoffsetbutton.UseVisualStyleBackColor = true;
            this.settoffsetbutton.Click += new System.EventHandler(this.button1_Click);
            // 
            // offsetlabel
            // 
            this.offsetlabel.AutoSize = true;
            this.offsetlabel.Location = new System.Drawing.Point(7, 0);
            this.offsetlabel.Name = "offsetlabel";
            this.offsetlabel.Size = new System.Drawing.Size(67, 13);
            this.offsetlabel.TabIndex = 0;
            this.offsetlabel.Text = "Niko\'s Offset";
            // 
            // fixoffsettimer
            // 
            this.fixoffsettimer.Enabled = true;
            this.fixoffsettimer.Interval = 500;
            this.fixoffsettimer.Tick += new System.EventHandler(this.fixoffsettimer_Tick);
            // 
            // nikosroom_door
            // 
            this.nikosroom_door.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nikosroom_door.BackColor = System.Drawing.Color.Transparent;
            this.nikosroom_door.Cursor = System.Windows.Forms.Cursors.Hand;
            this.nikosroom_door.Image = global::Niko_Cat_Desktop.Properties.Resources.door;
            this.nikosroom_door.Location = new System.Drawing.Point(0, 540);
            this.nikosroom_door.Name = "nikosroom_door";
            this.nikosroom_door.Size = new System.Drawing.Size(32, 63);
            this.nikosroom_door.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.nikosroom_door.TabIndex = 2;
            this.nikosroom_door.TabStop = false;
            this.nikosroom_door.Click += new System.EventHandler(this.nikosroom_door_Click);
            this.nikosroom_door.MouseLeave += new System.EventHandler(this.nikosroom_door_MouseLeave);
            this.nikosroom_door.MouseHover += new System.EventHandler(this.nikosroom_door_MouseHover);
            // 
            // pancakes
            // 
            this.pancakes.BackColor = System.Drawing.Color.Transparent;
            this.pancakes.Image = global::Niko_Cat_Desktop.Properties.Resources.pancakes;
            this.pancakes.Location = new System.Drawing.Point(0, 0);
            this.pancakes.Name = "pancakes";
            this.pancakes.Size = new System.Drawing.Size(25, 32);
            this.pancakes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pancakes.TabIndex = 1;
            this.pancakes.TabStop = false;
            this.pancakes.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pancakes.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            // 
            // niko
            // 
            this.niko.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.niko.BackColor = System.Drawing.Color.Transparent;
            this.niko.ContextMenuStrip = this.contextMenuStrip1;
            this.niko.Image = global::Niko_Cat_Desktop.Properties.Resources.nikodown;
            this.niko.Location = new System.Drawing.Point(380, 540);
            this.niko.Name = "niko";
            this.niko.Size = new System.Drawing.Size(40, 54);
            this.niko.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.niko.TabIndex = 0;
            this.niko.TabStop = false;
            this.niko.MouseDown += new System.Windows.Forms.MouseEventHandler(this.niko_MouseDown);
            this.niko.MouseMove += new System.Windows.Forms.MouseEventHandler(this.niko_MouseMove);
            this.niko.MouseUp += new System.Windows.Forms.MouseEventHandler(this.niko_MouseUp);
            // 
            // randomstoppingTimer
            // 
            this.randomstoppingTimer.Enabled = true;
            this.randomstoppingTimer.Interval = 13000;
            this.randomstoppingTimer.Tick += new System.EventHandler(this.randomstoppingTimer_Tick);
            // 
            // muteFootstepsToolStripMenuItem
            // 
            this.muteFootstepsToolStripMenuItem.Name = "muteFootstepsToolStripMenuItem";
            this.muteFootstepsToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.muteFootstepsToolStripMenuItem.Text = "Mute Footsteps";
            this.muteFootstepsToolStripMenuItem.Click += new System.EventHandler(this.muteFootstepsToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.nikooffsetpanel);
            this.Controls.Add(this.nikosroom_door);
            this.Controls.Add(this.pancakes);
            this.Controls.Add(this.niko);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Niko";
            this.TopMost = true;
            this.TransparencyKey = System.Drawing.Color.Black;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.nikooffsetpanel.ResumeLayout(false);
            this.nikooffsetpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OffsetnumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nikosroom_door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pancakes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.niko)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.PictureBox niko;
        private System.Windows.Forms.Timer moveTimer;
        private System.Windows.Forms.Timer messageTimer;
        private System.Windows.Forms.PictureBox pancakes;
        private System.Windows.Forms.Timer CheckNikowasFed;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem nikosStatusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem googleStuffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem standStillToolStripMenuItem;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Timer AppDetectTimer;
        private System.Windows.Forms.PictureBox nikosroom_door;
        private System.Windows.Forms.ToolStripMenuItem askNikoAQuestionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hideNikosRoomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem turbooooooooooooToolStripMenuItem;
        private System.Windows.Forms.Panel nikooffsetpanel;
        private System.Windows.Forms.Button settoffsetbutton;
        private System.Windows.Forms.Label offsetlabel;
        private System.Windows.Forms.ToolStripMenuItem nikosOffsetPanelToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown OffsetnumericUpDown;
        private System.Windows.Forms.Timer fixoffsettimer;
        private System.Windows.Forms.ToolStripMenuItem playAGameWithNikoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nikoSaysToolStripMenuItem;
        private System.Windows.Forms.Timer randomstoppingTimer;
        private System.Windows.Forms.ToolStripMenuItem muteFootstepsToolStripMenuItem;
    }
}

