﻿
namespace Niko_Cat_Desktop
{
    partial class nikosroom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(nikosroom));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.interactbed = new System.Windows.Forms.Panel();
            this.interactcomputer = new System.Windows.Forms.Panel();
            this.hoverTimer = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cooldownTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.NavajoWhite;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("MV Boli", 5.25F);
            this.textBox1.Location = new System.Drawing.Point(198, 136);
            this.textBox1.MaxLength = 250;
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(29, 32);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "this is a note";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::Niko_Cat_Desktop.Properties.Resources.nikodown;
            this.pictureBox1.Location = new System.Drawing.Point(227, 217);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 54);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseEnter += new System.EventHandler(this.pictureBox1_MouseEnter);
            this.pictureBox1.MouseLeave += new System.EventHandler(this.pictureBox1_MouseLeave);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // interactbed
            // 
            this.interactbed.BackColor = System.Drawing.Color.Transparent;
            this.interactbed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.interactbed.Location = new System.Drawing.Point(144, 164);
            this.interactbed.Name = "interactbed";
            this.interactbed.Size = new System.Drawing.Size(48, 63);
            this.interactbed.TabIndex = 2;
            this.interactbed.Click += new System.EventHandler(this.panel1_Click);
            // 
            // interactcomputer
            // 
            this.interactcomputer.BackColor = System.Drawing.Color.Transparent;
            this.interactcomputer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.interactcomputer.Location = new System.Drawing.Point(227, 164);
            this.interactcomputer.Name = "interactcomputer";
            this.interactcomputer.Size = new System.Drawing.Size(40, 37);
            this.interactcomputer.TabIndex = 0;
            this.interactcomputer.Click += new System.EventHandler(this.interactcomputer_Click);
            this.interactcomputer.MouseEnter += new System.EventHandler(this.interactcomputer_MouseEnter);
            this.interactcomputer.MouseLeave += new System.EventHandler(this.interactcomputer_MouseLeave);
            // 
            // hoverTimer
            // 
            this.hoverTimer.Interval = 3500;
            this.hoverTimer.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Press [E] to change gesture. | Cursor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(172, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Click to Change.";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // cooldownTimer
            // 
            this.cooldownTimer.Interval = 3500;
            this.cooldownTimer.Tick += new System.EventHandler(this.cooldownTimer_Tick);
            // 
            // nikosroom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::Niko_Cat_Desktop.Properties.Resources.nikosroomfinal;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(583, 406);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.interactcomputer);
            this.Controls.Add(this.interactbed);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "nikosroom";
            this.Text = "Niko\'s Room";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nikosroom_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Panel interactbed;
        private System.Windows.Forms.Panel interactcomputer;
        private System.Windows.Forms.Timer hoverTimer;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer cooldownTimer;
    }
}