﻿
namespace Niko_Cat_Desktop
{
    partial class nikosays
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.redpanel = new System.Windows.Forms.Panel();
            this.greenpanel = new System.Windows.Forms.Panel();
            this.yellowpanel = new System.Windows.Forms.Panel();
            this.bluepanel = new System.Windows.Forms.Panel();
            this.nikostanding = new System.Windows.Forms.PictureBox();
            this.nikosaid = new System.Windows.Forms.Label();
            this.thinkTimer = new System.Windows.Forms.Timer(this.components);
            this.checkTimer = new System.Windows.Forms.Timer(this.components);
            this.yellowpanel.SuspendLayout();
            this.bluepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nikostanding)).BeginInit();
            this.SuspendLayout();
            // 
            // redpanel
            // 
            this.redpanel.BackColor = System.Drawing.Color.Red;
            this.redpanel.Location = new System.Drawing.Point(0, 0);
            this.redpanel.Name = "redpanel";
            this.redpanel.Size = new System.Drawing.Size(300, 250);
            this.redpanel.TabIndex = 0;
            this.redpanel.MouseEnter += new System.EventHandler(this.redpanel_MouseEnter);
            this.redpanel.MouseLeave += new System.EventHandler(this.redpanel_MouseLeave);
            // 
            // greenpanel
            // 
            this.greenpanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.greenpanel.BackColor = System.Drawing.Color.Green;
            this.greenpanel.Location = new System.Drawing.Point(0, 250);
            this.greenpanel.Name = "greenpanel";
            this.greenpanel.Size = new System.Drawing.Size(300, 250);
            this.greenpanel.TabIndex = 0;
            this.greenpanel.MouseEnter += new System.EventHandler(this.greenpanel_MouseEnter);
            this.greenpanel.MouseLeave += new System.EventHandler(this.greenpanel_MouseLeave);
            // 
            // yellowpanel
            // 
            this.yellowpanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.yellowpanel.BackColor = System.Drawing.Color.Yellow;
            this.yellowpanel.Controls.Add(this.nikostanding);
            this.yellowpanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.yellowpanel.Location = new System.Drawing.Point(298, 0);
            this.yellowpanel.Name = "yellowpanel";
            this.yellowpanel.Size = new System.Drawing.Size(302, 250);
            this.yellowpanel.TabIndex = 0;
            this.yellowpanel.MouseEnter += new System.EventHandler(this.yellowpanel_MouseEnter);
            this.yellowpanel.MouseLeave += new System.EventHandler(this.yellowpanel_MouseLeave);
            // 
            // bluepanel
            // 
            this.bluepanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bluepanel.BackColor = System.Drawing.Color.MediumBlue;
            this.bluepanel.Controls.Add(this.nikosaid);
            this.bluepanel.Location = new System.Drawing.Point(298, 250);
            this.bluepanel.Name = "bluepanel";
            this.bluepanel.Size = new System.Drawing.Size(302, 250);
            this.bluepanel.TabIndex = 0;
            this.bluepanel.MouseEnter += new System.EventHandler(this.bluepanel_MouseEnter);
            this.bluepanel.MouseLeave += new System.EventHandler(this.bluepanel_MouseLeave);
            // 
            // nikostanding
            // 
            this.nikostanding.BackColor = System.Drawing.Color.Transparent;
            this.nikostanding.Image = global::Niko_Cat_Desktop.Properties.Resources.nikodown;
            this.nikostanding.Location = new System.Drawing.Point(250, 3);
            this.nikostanding.Name = "nikostanding";
            this.nikostanding.Size = new System.Drawing.Size(40, 54);
            this.nikostanding.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.nikostanding.TabIndex = 0;
            this.nikostanding.TabStop = false;
            // 
            // nikosaid
            // 
            this.nikosaid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.nikosaid.AutoSize = true;
            this.nikosaid.BackColor = System.Drawing.Color.White;
            this.nikosaid.Location = new System.Drawing.Point(67, 227);
            this.nikosaid.Name = "nikosaid";
            this.nikosaid.Size = new System.Drawing.Size(232, 13);
            this.nikosaid.TabIndex = 1;
            this.nikosaid.Text = "Niko is thinking what do you need to stand on...";
            // 
            // thinkTimer
            // 
            this.thinkTimer.Enabled = true;
            this.thinkTimer.Interval = 2000;
            this.thinkTimer.Tick += new System.EventHandler(this.thinkTimer_Tick);
            // 
            // checkTimer
            // 
            this.checkTimer.Interval = 3500;
            this.checkTimer.Tick += new System.EventHandler(this.checkTimer_Tick);
            // 
            // nikosays
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 499);
            this.Controls.Add(this.greenpanel);
            this.Controls.Add(this.bluepanel);
            this.Controls.Add(this.yellowpanel);
            this.Controls.Add(this.redpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "nikosays";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Niko Says";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.yellowpanel.ResumeLayout(false);
            this.yellowpanel.PerformLayout();
            this.bluepanel.ResumeLayout(false);
            this.bluepanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nikostanding)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel redpanel;
        private System.Windows.Forms.Panel greenpanel;
        private System.Windows.Forms.Panel yellowpanel;
        private System.Windows.Forms.Panel bluepanel;
        private System.Windows.Forms.PictureBox nikostanding;
        private System.Windows.Forms.Label nikosaid;
        private System.Windows.Forms.Timer thinkTimer;
        private System.Windows.Forms.Timer checkTimer;
    }
}